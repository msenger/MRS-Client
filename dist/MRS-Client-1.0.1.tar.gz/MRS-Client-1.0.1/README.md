A SOAP-based client of the MRS Retrieval server.
